﻿from .src import run


def build_hook():
    run()
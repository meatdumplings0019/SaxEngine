﻿def run():
    print("TEST PLUGINS")